<?php
require 'function.php';
$data=queryBuku("select*from isi");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV AL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="gambar"><img src="ayaa.JPEG" alt="aya">
            </div>
     <?php
foreach ($data as $cari):

     ?>
            <h1><?php echo $cari["nama"] ?></h1>
            <h4><?php echo $cari["hobi"] ?></h4>
    <?php
 endforeach;
    ?>
        </div>
        <div class="main">
            <div class="left">
                <h2>Informasi Identitas</h2>
                <p><strong>Nama</strong>  <?php echo $cari["nama"] ?></p>
                <p><strong>Alamat</strong>  <?php echo $cari["alamat"] ?></p>
                <p><strong>No.Telepon</strong>  <?php echo $cari["telepon"] ?></p>
                <p><strong>Skil</strong>  <?php echo $cari["skil"] ?></p>
                <p><strong>Jenis Kelamin</strong>  <?php echo $cari["jenis_kelamin"] ?></p>
                <h2>Pendidikan</h2>
                <p><strong>  <?php echo $cari["pendidikan"] ?></strong></p>
            </div>
            <div class="right">
                <h2>Pekerjaan</h2>
                <p><strong>  <?php echo $cari["pekerjaan"] ?></strong></p>

                <h3>Kepribadian</h3>
                <p><strong>Sifat Saya</strong></p>
                <li><?php echo $cari["kepribadian"] ?></li>
            </div>
        </div>
    </div>
</body>
</html>