<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
    <head>
      <title>Data CV</title>
          <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.PNG" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">CV AL YUTIKA</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-siswa.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
      
          </ul>
          <div class="konten">
            <h1>CV - Sederhana</h1>
            <h2>Selamat datang di Halaman CV </h2>
            <p>Dengan adanya website CV ini mempermudah dalam Perkenalan</p>                                                        
          </div>
         
          <div class="fotter">
            <p>Hak Cipta 2025 © Pengembangan Perangkat Lunak dan Gim</p>
          </div>
    </body>
</html>