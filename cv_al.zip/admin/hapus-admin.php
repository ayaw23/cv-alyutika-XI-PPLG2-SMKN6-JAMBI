<?php
session_start();
if (!isset($_SESSION["login"])){
    header("location: login.php");
    exit;
}
require 'function.php';
$hapus=$_GET["no"];
if(hapusadmin($hapus)>0){
    echo"
    <script>
    alert('data berhasil dihapus');
    document.location.href='data-admin.php';
    </script>
    ";
}

?>