<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
$hapus=$_GET["no"];
$data=queryBuku("select*from isi where no=$hapus");
if(isset($_POST["tombol"])){
   if(editSiswa($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Diedit');
        document.location.href='data-siswa.php';
        </script>
        ";
        }
        else{echo"Gagal";}
}

?>
<!doctype html>
<html>
<head>
<title>
Edit CV

</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<div class="header">
             <div class="header-logo">
             <img src="logo.PNG" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">CV AL YUTIKA</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-siswa.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
      
          </ul>
          <div class="konten">


<?php
foreach ($data as $cari):
    ?>
  
<h1> Data CV </h1>
<br>
<form method="POST">
<input type="hidden" name="no" value="<?php echo $cari["no"]     ?>">


<ul>
<li><label> Nama </label></li>
<li><input type="text" name="nama" value="<?php echo $cari["nama"];?>"></li>

<li><label> Jenis Kelamin</label></li>
<li>
    <select name="jenis_kelamin" required>
        <option value="">Pilih</option>
        <?php
        if ($cari["jenis_kelamin"]=="Laki-Laki") echo "<option value='Laki-Laki' selected>Laki-Laki </option>";
        else echo "<option value='Laki-Laki' selected>Laki-Laki </option>";

        if ($cari["jenis_kelamin"]=="Perempuan") echo "<option value='Perempuan' selected>Perempuan </option>";
        else echo "<option value='Perempuan' selected>Perempuan </option>";
        ?>
    </select>
    </li>

<li><label> Alamat </label></li>
<li><input type="text" name="alamat" value="<?php echo $cari["alamat"];?>"></li>

<li><label> Telepon </label></li>
<li><input type="text" name="telepon" value="<?php echo $cari["telepon"];?>"></li>

<li><label> Skil </label></li>
<li><input type="text" name="skil" value="<?php echo $cari["skil"];?>"></li>

<li><label> Hobi </label></li>
<li><input type="text" name="hobi" value="<?php echo $cari["hobi"];?>"></li>

<li><label> Pendidikan </label></li>
<li><textarea type="text" name="pendidikan" ><?php echo $cari["pendidikan"];?></textarea></li>

<li><label> Pekerjaan </label></li>
<li><textarea type="text" name="pekerjaan" ><?php echo $cari["pekerjaan"];?></textarea></li>

<li><label> Kepribadian </label></li>
<li><textarea type="text" name="kepribadian" ><?php echo $cari["kepribadian"];?></textarea></li>

<li><button type="submit" name="tombol"> Simpan </button> </li>

</ul>

<?php
 endforeach;
?>
</form>
</body>
</html>