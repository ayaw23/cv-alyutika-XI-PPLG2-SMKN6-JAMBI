<?php
session_start();
$database=mysqli_connect("Localhost","root","", "cv_al");
if(isset ($_POST["tombol"])){
    $username = $_POST ["username"];
    $password = $_POST ["password"];
    $cari = mysqli_query ($database,"SELECT*FROM login WHERE
    username = '$username' and password = '$password'");

    if (mysqli_num_rows ($cari)=== 1){
        $_SESSION ["login"]= true;
        header ("Location: index.php");
        exit;
    }
    $error = true;
 
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login CV</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  
  <div class="container">
    <div class="myform">
<?php if (isset($error)): ?>
  <p>user/password salah</p>
  <?php endif; ?>

      <form action="" method="post">
        <h2>ADMIN LOGIN</h2>
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button type="submit" name="tombol" >LOGIN</button>
      </form>
    </div>
    <div class="image">
      <img src="logo.PNG">
    </div>
  </div>
</body>
</html>