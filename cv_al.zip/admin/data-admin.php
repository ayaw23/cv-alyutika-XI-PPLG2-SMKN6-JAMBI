<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
$kol=mysqli_query($database,"select*from login");
if (isset ($_POST["tombol"])){
    $pencarian=$_POST ["pencarian"];
    $datayangdicari= "select*from login where
    username like '%$pencarian%'";
$kol=mysqli_query($database,$datayangdicari);
} else {
    $kol=mysqli_query($database,"select*from login");
}



?>
<!DOCTYPE html>
<html>
    <head>
      <title>Data Admin</title>
          <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
    <div class="header">
             <div class="header-logo">
             <img src="logo.PNG" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">CV AL YUTIKA</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-siswa.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
          </ul>
          <div class="konten">

<h1>Admin</h1>
<a href="tambah-admin.php">tambah admin</a></td>


<form action="" method="post">
    <input type="text" name="pencarian">
    <button type="submit" name="tombol">cari</button>
</form>
<table border="1" cellpadding="10" cellspacing="0">
<tr class="table-admin"><th>No</th>
        <th>Username</th>
        <th>Password</th>
        <th>aksi</th>
    </tr>

    </tr>
    <?php
    $nomor=1;
    ?>
    <?php
    foreach ($kol as $kill):
        ?>
        <tr><td class="table-admin1"><?=$nomor;   ?></td>
    <td class="table-admin2"><?php echo $kill["username"]   ?></td>
    <td class="table-admin3"><?php echo $kill["password"]   ?></td>
   
    <td class="table-admin4"><a href="hapus-admin.php?no=<?php echo $kill["no"]?>">hapus</a> |
    <a href="edit-admin.php?no=<?php echo $kill["no"]?>">edit</a></td>
    </tr>
    <?php
    $nomor++;
    ?>
    <?php
    endforeach;
    ?>
    </table>
   
          
    </body>
</html>