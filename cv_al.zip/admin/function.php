<?php
$database= mysqli_connect("localhost","root","","cv_al");

function queryBuku ($queryBuku){
    global $database;
  $tampilkan = mysqli_query($database, $queryBuku);
  $wadahkosong = [];
  while( $data =mysqli_fetch_assoc($tampilkan)){
    $wadahkosong [] =$data;
  }
  return $wadahkosong;
}


function tambahSiswa($tambahSiswa){
    global $database;
    $nama=$_POST["nama"];
    $kelas=$_POST["jenis_kelamin"];
    $jurusan=$_POST["alamat"];
    $no_hp=$_POST["telepon"];
    $rw=$_POST["skil"];
    $hobi=$_POST["hobi"];
    $pendidikan=$_POST["pendidikan"];
    $pekerjaan=$_POST["pekerjaan"];
    $kepribadian=$_POST["kepribadian"];
    $tambah_biodata="insert into isi values
    ('','$nama','$kelas','$jurusan','$no_hp','$rw','$hobi','$pendidikan','$pekerjaan','$kepribadian')"; 
    mysqli_query($database,$tambah_biodata);
    return mysqli_affected_rows($database);
}
function hapusSiswa($hapusSiswa){
    global $database;
    mysqli_query($database,"delete from isi where no=$hapusSiswa");
    return mysqli_affected_rows($database);
}
function editSiswa($editSiswa){
    global $database;
    $hapus=$_GET["no"];
    $nis=$_POST["no"];

    $nama=$_POST["nama"];
    $kelas=$_POST["jenis_kelamin"];
    $jurusan=$_POST["alamat"];
    $no_hp=$_POST["telepon"];
    $email=$_POST["skil"];
    $hobi=$_POST["hobi"];
    $pendidikan=$_POST["pendidikan"];
    $pekerjaan=$_POST["pekerjaan"];
    $kepribadian=$_POST["kepribadian"];

    $edit = "update isi set  

    nama = '$nama',
    jenis_kelamin = '$kelas',
    alamat = '$jurusan',
    telepon = '$no_hp',
    skil ='$email',
    hobi ='$hobi',
    pendidikan ='$pendidikan',
    pekerjaan ='$pekerjaan',
    kepribadian ='$kepribadian'
    where no =$hapus"; 
    mysqli_query($database,$edit);
    return mysqli_affected_rows($database);
}
function tambahadmin ($tambahadmin){
    global $database;
    $no=$_POST["no"];
    $nip=$_POST["username"];
    $nama_petugas=$_POST["password"];
    
    $tambah_data="insert into login value
    ('','$nip','$nama_petugas')";
    mysqli_query($database,$tambah_data);
    return mysqli_affected_rows($database);
}
function hapusadmin ($hapusadmin){
    global $database;
    mysqli_query($database,"delete from login where no=$hapusadmin");
    return mysqli_affected_rows($database);
}
function editadmin ($editadmin){
    global $database;
    $hapus=$_GET["no"];
    $no=$_POST["no"];
    $nip=$_POST["username"];
    $nama_petugas=$_POST["password"];
    $edit="update login set
    no = '$no',
    username = '$nip',
    password = '$nama_petugas'
    where no=$hapus";
    mysqli_query($database,$edit);
    return mysqli_affected_rows($database);


}

?>