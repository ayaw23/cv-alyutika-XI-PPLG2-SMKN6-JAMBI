<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
if(isset($_POST["tombol"])){
    if(tambahSiswa($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Ditambahkan');
        document.location.href='data-siswa.php';
        </script>
        ";
        }
        else{echo"Gagal";}

}
    

?>
<!doctype html>
<html>
<head>
<title>
Tambah CV


</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<div class="header">
             <div class="header-logo">
             <img src="logo.PNG" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">CV AL YUTIKA</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-siswa.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
          </ul>
          <div class="konten">



<h1> Tambah Data </h1>
<br>
<form method="POST">

<ul>
<li><label> Nama </label></li>
<li><input type="text" name="nama" required></li>
<li><label> Jenis Kelamin</label></li>
<li>
    <select name="jenis_kelamin" required>
    <option>Laki-Laki</option>
    <option>Perempuan</option>
    </select>
    </li>
<li><label> Alamat</label></li>
<li><input type="text" name="alamat" required></li>
<li><label> Telepon</label></li>
<li><input type="text" name="telepon" required></li>
<li><label> Skil</label></li>
<li><input type="text" name="skil" required></li>
<li><label> Hobi</label></li>
<li><input type="text" name="hobi" required></li>
<li><label> Pendidikan</label></li>
<li><textarea name="pendidikan" ></textarea></li>
<li><label> Pekerjaan</label></li>
<li><textarea name="pekerjaan" id="" ></textarea></li>
<li><label> Kepribadian</label></li>
<li><textarea name="kepribadian" id="" ></textarea></li>
<li><button type="submit" name="tombol"> Simpan </button> </li>
</ul>

</form>
</body>
</html> 