<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
$nomor=$_GET["no"];
$kol=mysqli_query($database,"select*from login where no=$nomor");
if (isset($_POST["tombol"])){
    if(editadmin($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Diedit');
        document.location.href='data-admin.php';
        </script>
        ";
        }
        else{echo"Gagal";}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Admin</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
             <div class="header-logo">
             <img src="logo.PNG" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">CV AL YUTIKA</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-buku.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
          </ul>
          <div class="konten">
          <?php
       while($data=mysqli_fetch_assoc($kol)):
       ?>
       <h1>Edit admin</h1>
       
       <form method="POST">
       <input type="hidden" name="no" value="<?php echo $data["no"]     ?>">

        <ul>
       <li><label for="">username</label></li>
       <li><input type="text"name="username"    value="<?php echo $data ["username"]; ?>"></li>
       <li><label for="">password</label></li>
       <li><input type="text"name="password"    value="<?php echo $data ["password"]; ?>"></li>
       <li><button type="submit" name="tombol">kirim edit data</button></li>
      </ul>
      <?php 
      endwhile;
      ?>
      </form>
    </div>
    </body>
    </html>