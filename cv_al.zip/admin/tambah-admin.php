<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
if (isset($_POST["tombol"])){  
if(tambahadmin($_POST)>0){
    echo"
    <script>
    alert('data berhasil ditambahkan');
    document.location.href='data-admin.php';
    </script>
    ";
}else{echo "<script>
    alert ('data gagal di simpan');
    document.location.href='data-admin.php';
    </script>";
}}
?>
<!DOCTYPE html>
<head>
    <title>tambah admin</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
             <div class="header-logo">
             <img src="logo.PNG" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">CV AL YUTIKA</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-buku.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
          </ul>
          <div class="konten">

    <h1>tambah admin</h1>
    <br>
    <form method="post">
<ul>
    <li><label>username</label></li>
    <li><input type="text" name="username"></li>
    <li><label>password</label></li>
    <li><input type="text" name="password"></li>
    <li><button type="submit" name="tombol"> Simpan </button> </li>
</ul>
</form>

</body>
</html>