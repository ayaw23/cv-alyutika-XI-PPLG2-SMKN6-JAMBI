<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
$hapus=$_GET["no"];
if(hapusSiswa($hapus)>0){
    echo "
    <script>
    alert('Data Berhasil Dihapus');
    document.location.href='data-siswa.php';
    </script>
    ";
    }
    
?>